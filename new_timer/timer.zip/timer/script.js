const btn = document.getElementById('btn');
const pom = document.getElementById('pom');
const short = document.getElementById('short');
const long = document.getElementById('timer');

const timer = document.getElementById('timer');
const breack = document.getElementById('breack');
const longBrack = document.getElementById('longBreack');

// function start(a) {
let a = 1500;
function date() {
  min = parseInt((a / 60) % 60);
  sec = parseInt(a % 60);
  sec = sec < 10 ? '0' + sec : sec;
  timeBlock = `${Math.trunc(min)}:${sec}`;
  timer.innerHTML = timeBlock;
}

let openStart = false;
let timeOut;

btn.addEventListener('click', () => {
  date();
  if (!openStart) {
    timeOut = setInterval(() => {
      --a;
      date();
    }, 1000);

    openStart = true;
  } else {
    setInterval(timeOut, 1000);

    clearInterval(timeOut);

    openStart = false;
  }
});
date();

function poma() {
  // breack.style.display = 'block';
  a = 1500;
  date();
}
function shorten() {
  // breack.style.display = 'block';
  a = 300;
  date();
}
function longen() {
  // breack.style.display = 'block';
  a = 900;
  date();
}


//Находим Элемент
 const form = document.querySelector('#form')
 const taskInput = document.querySelector('#task_input')
 const taskList = document.querySelector('.task_list')

 let tasks = [];/* - массив задач
 */

// if(localStorage.getItem('tasksHTML')) {
//   taskList.innerHTML =localStorage.getItem('tasksHTML')
// }


 // Добавление задачи
 form.addEventListener('submit',
   addTask
  
 )
 // удаление Задачи 

taskList.addEventListener('click',deleteTask)




function deleteTask(event){
  if(event.target.dataset.action==='delete') {
   const parentNode = event.target.closest('li')
   
  // Определяем id задачи

  const id =Number(parentNode.id)

// Находим id задачи в массиве
  // const index =  tasks.findIndex((task) => task.id==id)
  
  // if(task.id==id) {
  //   return true
  // }
 



 // удаляем задачу из массива с задачами
//  tasks.splice(index,1)


 tasks =tasks.filter((task)=>task.id !== id)


// удаляем из разметки
    parentNode.remove()

  }
  // saveHTMLtolLS()
}

 function addTask(event){
  event.preventDefault()  
  //  - отменяет стандартное поведение(   event.preventDefault() )

  // Достаем текст

   const taskText =taskInput.value
   
const newTask = {
  id:Date.now(),
  text:taskText,
  done:false
};



//Добавить задачу в массив с задачами
tasks.push(newTask );

//Формируем CSS класс
const cssClass = newTask.done?"task-title--done": '';
   //Формируем разметку для новой задачи

   const taskHTML = `<li id="${newTask.id}">
   <span class="${cssClass}">${newTask.text}</span>
   <button data-action="done">Выполнено</button>
   <button data-action="delete">Удалить</button>
 </li>`
// taskList.innerHTML=taskHTML мы вставим через  insertAdjacentHTML
taskList.insertAdjacentHTML('beforeend',taskHTML)

//Очищаем поле ввода и возвращаем на него фокус

taskInput.value='';
taskInput.focus()

// saveHTMLtolLS()
}

//Отмечаем Задачу завершенной
taskList.addEventListener('click',doneTask)

function doneTask(event){
  if(event.target.dataset.action==='done') {
    const parentNode = event.target.closest('li')
   const taskTitle = parentNode.querySelector('span')
   taskTitle.classList.toggle('color')

   const id= parentNode.id
   const task= tasks.find((task)=>task.id==id )

   task.done=!task.done
   console.log(task)
  }
  // saveHTMLtolLS()
}

// function saveHTMLtolLS(){
//   localStorage.setItem('tasksHTML',taskList.innerHTML)
// }






























//todo
// const addMessage = document.querySelector('.message')
// const addButton =document.querySelector('.add')
// const todo = document.querySelector('.todo')

// let todoList = [];
// if(localStorage.getItem('todo')) {
//   todoList=JSON.parse(localStorage.getItem('todo'));
//   displayMessages();
// }

// addButton.addEventListener('click',()=> {
//   console.log(addMessage.value)


//   let newTodo = {
//    todo:addMessage.value,
//    checked:false,
//    important:false
//   }

//   todoList.push(newTodo)
//   displayMessages()
//   localStorage.setItem('todo',JSON.stringify(todoList))
// addMessage.value=''
//   console.log(todoList)
// })


// function displayMessages(){
//   let displayMessage =''
//    todoList.forEach(function(item,i){
//     displayMessage +=`
//      <li>
//      <input type='checkbox'  id='item_${i}' ${item.checked ? 'checked':''}>
//      <label for='item_${i}'>${item.todo}</label>
     
//      </li>

//      `
//      todo.innerHTML=displayMessage

//    })
// }
// todo.addEventListener('change',function(event){
//    let idInput =event.target.getAttribute('id')
//    let forLabel = todo.querySelector('[for='  + idInput +']')
// })